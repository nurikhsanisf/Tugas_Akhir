<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Laptop;

class FilterLaptopController extends Controller
{
    //
    public function index() {
        // var_dump("saya");
    }

    public function store(Request $request) {
        // $params_input = $request->input();

        // $listLaptop = Laptop::all();

        // $countListLaptop = $listLaptop->count();


        // foreach($listLaptop as $key => $document) {

        //     foreach($params_input as $param) {
                
        //     }
        // }

        $company            = $request->company;
        $product            = $request->product;
        $typename           = $request->typename;
        $inches             = $request->inches;
        $screenresolution   = $request->screenresolution;
        $cpu                = $request->cpu;
        $ram                = $request->ram;
        $memory             = $request->memory;
        $gpu                = $request->gpu;
        $opsis              = $request->opsis;
        $weight             = $request->weight;
        
        $listLaptop = Laptop::all();
        

        $params_input = $request->input();

        $q = [];
        $queryNumber = 0;
        $documentKey = [];
        
        
        foreach($params_input as $key => $param){
            $queryNumber = $queryNumber + 1;
            $documentNumber = 0;
            $totalDocument = 0;
            $tf = [];
            $totaldf = 0;
            $tfDocument = [];
            $dBagiDf = 0;
            $idf = 0;
            $idfPlusSatu = 0;

            
            foreach($listLaptop as $detailLaptop){
                $documentNumber = $documentNumber + 1;
                $totalDocument = $totalDocument + 1;
                if($detailLaptop['company'] == $param || $detailLaptop['product'] == $param || $detailLaptop['typename'] == $param || $detailLaptop['inches'] == $param || $detailLaptop['screenresolution'] == $param || $detailLaptop['cpu'] == $param || $detailLaptop['ram'] == $param || $detailLaptop['memory'] == $param || $detailLaptop['gpu'] == $param || $detailLaptop['opsis'] == $param || $detailLaptop['weight'] == $param) {
                    $tf[] = 1;
                    $totaldf = $totaldf + 1;
                }else{
                    $tf[] = 0;
                    $totaldf = $totaldf + 0;
                }
            }
            // print_r($tf);

            if(!empty($totaldf)){
                $dBagiDf = $totalDocument/$totaldf;
                $idf = Log($dBagiDf, 10);
                $idfPlusSatu = $idf + 1;
            }

            foreach($tf as $detailtf) {
                if($detailtf == 1) {
                    $tfDocument[] = $idfPlusSatu;
                }else{
                    $tfDocument[] = 0;
                }
            }   
            
            $q[$param] = $tfDocument;
                   
        }

        $dokumen = [];
        foreach($listLaptop as $key => $document){
            $data1 = 0;
            foreach($params_input as $param) {
                $data1 = $data1 + $q[$param][$key];
            }
            $dokumen[] = $data1;
        }
        $max_keys = array_search(max($dokumen), $dokumen);
        return $listLaptop[$max_keys];
        // var_dump($listLaptop[$max_keys] );die;
        
      
        // var_dump($q);die;
        // die;
        // $a = $q["apple"][0] + $q["Macbook Air"]    [0] + $q["Ultrabook"][0] + $q["15.7"][0] + $q["1440x900"][0] + $q["Intel Core i7 2,2GHz"][0] + $q["16GB"][0] + $q["256GB SSD"][0] + $q["Intel Iris Plus Graphics 640"][0] + $q["macOs"][0] + $q["1,36kg"][0];
        // var_dump($a);
        // die;

        // for ($i = 0 ; $i < 11; ))
        
    }
}

